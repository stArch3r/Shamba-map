<?php

return [
    [
        'username' => 'okirlin',
        'auth_key' => 'iwTNae9t34OmnK6l4vT4IeaTk-YWI2Rv',
        'password_hash' => '$2y$13$CXT0Rkle1EMJ/c1l5bylL.EylfmQ39O5JlHJVFpNn618OUS1HwaIi',
        'password_reset_token' => 't5GU9NwpuGYSfb7FEZMAxqtuz2PkEvv_' . time(),
        'created_at' => '1391885313',
        'updated_at' => '1391885313',
        'email' => 'brady.renner@rutherford.com',
    ],
    [
        'username' => 'troy.becker',
        'auth_key' => 'EdKfXrx88weFMV0vIxuTMWKgfK2tS3Lp',
        'password_hash' => '$2y$13$g5nv41Px7VBqhS3hVsVN2.MKfgT3jFdkXEsMC4rQJLfaMa7VaJqL2',
        'password_reset_token' => '4BSNyiZNAuxjs5Mty990c47sVrgllIi_' . time(),
        'created_at' => '1391885313',
        'updated_at' => '1391885313',
        'email' => 'nicolas.dianna@hotmail.com',
        'status' => '0',
    ],
    [
        'username' => 'test.test',
        'auth_key' => 'O87GkY3_UfmMHYkyezZ7QLfmkKNsllzT',
        //Test1234
        'password_hash' => '$2y$13$d17z0w/wKC4LFwtzBcmx6up4jErQuandJqhzKGKczfWuiEhLBtQBK',
        'email' => 'test@mail.com',
        'status' => '9',
        'created_at' => '1548675330',
        'updated_at' => '1548675330',
        'verification_token' => '4ch0qbfhvWwkcuWqjN8SWRq72SOw1KYT_1548675330',
    ],
    [
        'username' => 'test2.test',
        'auth_key' => '4XXdVqi3rDpa_a6JH6zqVreFxUPcUPvJ',
        //Test1234
        'password_hash' => '$2y$13$d17z0w/wKC4LFwtzBcmx6up4jErQuandJqhzKGKczfWuiEhLBtQBK',
        'email' => 'test2@mail.com',
        'status' => '10',
        'created_at' => '1548675330',
        'updated_at' => '1548675330',
        'verification_token' => 'already_used_token_1548675330',
    ],
];
